<footer>
        <div>
			<p>
				c2022 All Rights Reserved.Designed by SYC IT Dep. 詹子寬
			</p>
		</div>
    </footer>
</body>
	<script src="js/app.js"></script>

	<!-- load jQuery and tablesorter scripts -->
	<!-- <script type="text/javascript" src="js/jquery-latest.js"></script> -->
	<script type="text/javascript" src="js/jquery.tablesorter.js"></script>

		<!-- tablesorter widgets (optional) -->
	<script type="text/javascript" src="js/jquery.tablesorter.widgets.js"></script>
</html>