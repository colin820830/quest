<?php
    session_start();
    header("Cache-Control:private");
?>