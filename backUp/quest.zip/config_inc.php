<?php

define('DB_HT_S','172.24.1.4');
define('DB_SD_S','SHUNGYE');
define('DB_UR_S','SHUNGYE');
define('DB_PD_S','SHUNGYE');


define('DB_HT_3','172.24.1.21');
define('DB_SD_3','YYC3');
define('DB_PD_3','YYCARD');
define('DB_UR_3','ARD');	

?>