<?
    require_once 'startsession.php';
    require_once 'header.php';
    require_once 'Id_chk.php';
?>


<main>

    <div class="form-group row m-3">
        <h3>單位系統參考對照表</h3>
    </div>

    <div class="form-group row m-3">
        <img src="./images/table01.jpg" class="img-fluid">
        <img src="./images/table02.jpg" class="img-fluid">
        <img src="./images/table03.jpg" class="img-fluid">
    </div>

    <!-- <div class="form-group row m-3">
        <div class="col-md-auto">
            <button type="button" onclick="history.back()" class="btn btn btn-danger">回上一頁</button>
        </div>
    </div> -->
</main>

<?php
    require_once 'footer.php';
?>