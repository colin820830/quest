<?php
	class QuestContent{
		
		//執行穩定度
		public $stablize = "";

		public $stablizeReason = "";

		//執行速度
		public $speed = "";

		public $speedReason = "";

		//系統操作界面
		public $operate = "";

		public $operateReason = "";

		//程式功能
		public $program = "";

		public $programReason = "";

		//資訊人員處理能力
		public $ability = "";

		public $abilityReason = "";
	}
?>